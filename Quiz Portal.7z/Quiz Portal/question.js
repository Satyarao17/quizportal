var questions = [
    {
          "question":"How to append CC and BCC mail address in the link of mailto" ,
           "option1":"Using !",
           "option2":"Using @",
           "option3":"Using ^",
           "option4":"Using &",
            "answer":"4"
    },

    {
            "question":"Text between <em> and </em> is displayed as?",
             "option1":"bold",
             "option2":"italic",
             "option3":"bold-italic",
             "option4":"indented",
             "answer":"2"
    },

    {
         "question":"syntax for list that lists items with number",
      
          "option1":"<ol>",
          "option2":"<ul>",
          "option3":"<list>",
           "option4":"<dl>",
           "answer":"1"
    },

    {   "question":"The script tag can be written in?",
     
         "option1":"Head Section",
           "option2":"Body Section",
          "option3":"External File",
          "option4":"All the above",
          "answer":"4"
    },

    {
          "question":"The correct syntax for removing underline from hyperlink",
        
            "option1":"list-style-type:none",
             "option2":"text-decoration:no-underline",
             "option3":"text-decoration:none",
             "option4":"text-style-type:no-underline",
             "answer":"3"
    }
];
 